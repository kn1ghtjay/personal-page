## 个人主页

好看的个人主页，个人主页源码，博客主页模板.**🉑️随意使用，无限制。**

预览地址：[https://weenxu.github.io/home](https://weenxu.github.io/home)

## 集成插件

- [x] [typed 打字机特效](https://github.com/mattboldt/typed.js/)
- [x] [Aplayer 音乐播放插件](https://github.com/MoePlayer/APlayer)
- [x] [Meting 强大的 Aplayer 辅助插件](https://github.com/metowolf/MetingJS)
- [x] [不蒜子计数](http://busuanzi.ibruce.info/)
- [x] [看板娘](https://github.com/stevenjoezhang/live2d-widget)

## 集成API

- [x] [一言](https://hitokoto.cn/)
- [x] [今日诗词](https://www.jinrishici.com/)
- [x] [随机图片](https://api.ixiaowai.cn/api/api.php) 

## 好玩的

- [x] 点击冒点
- [x] 雪花
- [x] 搞怪标题栏 
